#include <stdio.h>
void foo1(int x) {
  x = x + 1;
  printf("valor x = %d @foo1; no endereco %p\n", x, &x);
}
void foo2(int * x) {
  *x = *x + 1;
  printf("valor x = %d @foo2; no endereco %p\n", *x, x);
}
int main() {
  int x = 3;
  foo1(x);
  printf("valor x = %d @main apos foo1; endereco %p\n", x, &x);
  foo2(&x);
  printf("valor x = %d @main apos foo2; endereco %p\n", x, &x);
  return 0;
}
