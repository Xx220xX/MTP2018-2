#include<stdio.h>
void printa(char *vet){
    if(!*vet)return ;
    printa(vet+1);
    printf("%c",*vet);
}
int main(){
    char vet[250];
    gets(vet);
    printa(vet);
}
