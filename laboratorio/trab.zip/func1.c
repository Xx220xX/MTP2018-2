#include <stdio.h>
#include <math.h>
int somaFracao(int num1, int den1, int num2, int den2,int *n,int *d){
    if(den1*den2==0){
        return 0;
    }
    *n=num1*den2+num2*den1;
    *d =den1*den2;
    return 1;
}
int main() {
  int  x1,x2,a=1,b=-4,c=4,d;
     scanf("%d/%d,%d/%d",&a,&b,&c,&d);
    if(somaFracao(a,b,c,d,&x1,&x2)){
        printf("%d/%d \n",x1,x2);

    }else{
        printf("o denominador nao pode ser zero\n");
    }

}
