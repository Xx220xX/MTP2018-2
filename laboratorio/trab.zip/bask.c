#include <stdio.h>
#include <math.h>
float delta(float a,float b,float c){
    return b*b - (4*a*c);
}
void bask(float *x1,float *x2,float a, float b, float c){
    float d= delta(a,b,c);
    if(d<0){
        printf("nao possui raizes reais");
        return;
    }
    *x1= (-b+pow(d,0.5))/(2*a);
    *x2= (-b-pow(d,0.5))/(2*a);
}

int main() {
  float  x1,x2,a=1,b=-4,c=4;
  scanf("%f%f%f",&a,&b,&c);
  bask(&x1,&x2,a,b,c);
  printf("x1 = %g\nx2 = %g\n",x1,x2);
}
