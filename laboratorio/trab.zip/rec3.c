#include<stdio.h>
#include <stdio.h>
#include <math.h>
int mdc(int u,int v){
    if(u==v || v==0) return u;
    if(u==0)return v;
    if(u%2==0 && v%2!=0) return mdc(u/2,v);
    if(v%2==0 && u%2!=0) return mdc(u,v/2);
    if(v%2==0 && u%2==0) return 2*mdc(u/2,v/2);
    if(u>v)return mdc((u-v)/2,v);
    if(u<v)return mdc((v-u)/2,u);

}
int somaFracao(int num1, int den1, int num2, int den2,int *n,int *d){
    if(den1*den2==0){
        return 0;
    }
    *n=num1*den2+num2*den1;
    *d =den1*den2;
    return 1;
}
int main() {
  int  x1,x2,a=1,b=-4,c=4,d,m;
     scanf("%d/%d,%d/%d",&a,&b,&c,&d);
    if(somaFracao(a,b,c,d,&x1,&x2)){
        m=mdc(x1,x2);
    x1/=m;
    x2/=m;
        printf("%d/%d \n",x1,x2);

    }else{
        printf("o denominador nao pode ser zero\n");
    }

}
