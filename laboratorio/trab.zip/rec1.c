#include<stdio.h>
int soma(int *a, int n, int i){
   return i>=n?0: a[i]+soma(a,n,++i);
}
int main(){
    int A[] = {1, 3};
    int n = sizeof(A)/sizeof(int);
    int som=soma(A,n,0);
              printf("soma = %d",som);
}
