#include <stdio.h>
#include <math.h>

void intersecacao(int *a,int *b,int n1,int n2){
    int i,j;
    for(i=0;i<n1;i++){
        for(j=0;j<n2;j++){
             if(a[i]==b[j]){
                printf("%d ",a[i]);
             }
        }
    }
    printf("\n");
}

int main(){
    int A[] = {1, 3, 5, 7, 9, 11, 13, 15, 17, 19, 21, 23, 25, 27, 29, 31};
    int n = sizeof(A)/sizeof(int);
    int B[] = {1, 2, 3, 4, 5, 6, 8, 10, 12, 7, 29};
    int m = sizeof(B)/sizeof(int);
    intersecacao(A,B,n,m);
}
