#include <stdio.h>
#include <math.h>

void qr(int n,int d,int *q,int *r){
    *q=n/d;
    *r=n%d;
}



int main() {
  int n,d,q,r;
  scanf("%d,%d",&n,&d);
  qr(n,d,&q,&r);
  printf("%d,%d\n",q,r);

}
