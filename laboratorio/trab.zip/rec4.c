#include<stdio.h>
#include <math.h>
void (*foo)(double*,double*,int ,int);
void quad(double *a,double *b, int n, int i ){
    if(i>=n)return;
    *(a+i) = pow((a[i]+b[i]),0.5);
    quad(a,b,n,++i);
}
void b_3(double *a,double *b, int n, int i ){
    if(i>=n)return;
    a[i]=a[i]+3*b[i];
    b_3(a,b,n,++i);
}
void b_quad(double *a,double *b, int n, int i ){
    if(i>=n)return;
    a[i]=b[i]*b[i]/a[i];
    b_quad(a,b,n,++i);
}
void printar(double *vet, int n){
    int i=0;
    for(i=0;i<n;i++){
        printf("%lf ",vet[i]);
    }
}
int main(){
    double a[] = {1.0, 3.0, 5.0, 7.0, 9.0, 11.0, 13.0, 15.0, 17.0, 19.0, 21.0, 23.0, 25.0, 27.0, 29.0, 31.0};
    double b[] = {0.5, 0.25, 0.125, 0.0625, 0.5, 0.25, 0.125, 0.0625, 0.5, 0.25, 0.125, 0.0625, 0.5, 0.25, 0.125, 0.0625};
    int n = sizeof(a)/sizeof(double);
    int caso;
    scanf("%d",&caso);
    switch(caso){
    case 1:
        foo=quad;
        break;
    case 2:
        foo=b_3;
        break;
    case 3:
        foo=b_quad;
        break;
    }
    foo(a,b,n,0);
    printar(a,n);
}
