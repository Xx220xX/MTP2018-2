package com.classes;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Fracao {
    private int valor = 1;
    private int num = 1;
    private int den = 1;

    public Fracao(int valor) {
        this.valor = valor;
        this.num = valor;


    }

    public Fracao(Fracao b) {
        if (b == null) throw new NullPointerException("fracao vazia ");

        this.num = b.num;
        this.den = b.den;
        this.valor = b.valor;
        Fracao.simplificar(this);
    }

    public Fracao() {
        Fracao.simplificar(this);
    }

    public Fracao(int num, int den) {
        this.num = num;
        if (den < 0) {
            this.num *= -1;
            den *= -1;
        }
        this.den = den;
        simplificar(this);
    }

    public static Fracao StringToFracao(String fracao) {
        if (fracao == null) {
            return new Fracao();
        }
        Pattern pt = Pattern.compile("-?\\d+/-?\\d+");
        Pattern pt2 = Pattern.compile("-?\\d+");
        Matcher mt = pt.matcher(fracao);
        Matcher mt2 = pt2.matcher(fracao);
        if (mt.find()) {
            String str = fracao.substring(mt.start(), mt.end());
            mt2 = pt2.matcher(str);
            mt2.find();
            int num = Integer.valueOf(str.substring(mt2.start(), mt2.end()));
            mt2.find();
            int den = Integer.valueOf(str.substring(mt2.start(), mt2.end()));
            if (den != 0)
                return new Fracao(num, den);
            else
                return new Fracao(num);
        } else if (mt2.find()) {
            int num = Integer.valueOf(fracao.substring(mt2.start(), mt2.end()));
            return new Fracao(num);
        }
        return new Fracao();

    }

    //operacoes
    public static void subtrairFracao(Fracao a, Fracao b) {
        if (b.num == 0) return;
        int denominador = 0, numerador = 0;
        if (a.den != b.den) {
            denominador = a.den * b.den;
            a.num = denominador / a.den * a.num;
            numerador = denominador / b.den * b.num;
            a.den = denominador;
        } else {
            numerador = b.num;
        }
        a.num -= numerador;
        simplificar(a);
    }

    public static void somarFracao(Fracao a, Fracao b) {
        int Nden = 0, numB = 0;
        if (a.den != b.den) {
            Nden = a.den * b.den;
            a.num = Nden / a.den * a.num;
            numB = Nden / b.den * b.num;
            a.den = Nden;
        } else {
            numB = b.num;
        }
        a.num += numB;
        simplificar(a);
    }

    public static void dividir(Fracao f, int divisor) {
        f.den *= divisor;
        simplificar(f);
    }

    public static void multiplicar(Fracao f, int fator) {
        f.num *= fator;
        simplificar(f);
    }

    public static void dividir(Fracao f, Fracao divisor) {
        int Nden = divisor.den;
        f.den *= divisor.num;
        f.num *= Nden;
        simplificar(f);
    }

    public static Fracao multiplicar(Fracao f, Fracao fator, boolean retorna) {
        int numerador = (f.num * fator.num), denominador = (f.den * fator.den);

        Fracao b = new Fracao(numerador, denominador);
//        System.out.print("f "+f+"  f2  "+fator+" b");
        simplificar(b);
        return b;

    }

    public static void multiplicar(Fracao f, Fracao fator) {
        f.num *= fator.num;
        f.den *= fator.den;
        simplificar(f);
    }

    public static void simplificar(Fracao a) {
        if (a.num == 0) {
            a.den = 1;
            a.valor = 0;
            return;
        }
        int i = 0;
        if (a.num < 0 && a.den < 0 || a.den < 0) {
            a.num *= -1;
            a.den *= -1;
        }
        int nume = a.num, deno = a.den;
        if (nume < 0) {
            nume *= -1;
        }
        if (deno < 0) {
            deno *= -1;
        }
        if (nume > deno) {
            i = deno;
        } else {
            i = nume;
        }
        while (i > 1) {
            if (nume % i == 0 && deno % i == 0) {
                a.num /= i;
                a.den /= i;
                return;
            }
            i--;
        }

    }

    public static boolean comparaMaior(Fracao f, int numero) {
        return comparaMaior(f, numero, false);
    }

    public static boolean comparaMaior(Fracao f, int numero, boolean modulo) {
        int Nnum = numero, Nden = 1, fnum = f.num;

        if (f.den != 1) {
            Nden *= f.den;
            Nnum *= Nden;
        }
        if (modulo) {
            fnum = fnum < 0 ? fnum * -1 : fnum;
            Nnum = Nnum < 0 ? Nnum * -1 : Nnum;

        }
        if (fnum > Nnum) {
            return true;
        }
        return false;
    }

    public static boolean comparaMaior(Fracao f, Fracao b) {
        return comparaMaior(f, b, false);
    }

    public static boolean comparaMaior(Fracao f1, Fracao f2, boolean modulo) {
        //true f1>f2
        //false f1<f2
        int Nnum = f2.num, Nden = f2.den;
        int fnum = f1.num, fden = f1.den;
        if (fden != Nden) {
            Nden = f1.den * f2.den;
            Nnum = Nden / f2.den * Nnum;
            fden = Nden;
            fnum = Nden / f1.den * f1.num;
        }
        if (modulo) {
            fnum = fnum < 0 ? fnum * -1 : fnum;
            Nnum = Nnum < 0 ? Nnum * -1 : Nnum;

        }
        if (fnum > Nnum) {
            return true;
        }
        return false;
    }

    public static Fracao somarFracao(Fracao f1, Fracao f2, boolean b) {
        int Nden = 0, numB = 0;
        Fracao c = new Fracao();
        if (f1.den != f2.den) {
            Nden = f1.den * f2.den;
            c.num = Nden / f1.den * f1.num;
            numB = Nden / f2.den * f2.num;
            c.den = Nden;
        } else {
            numB = f2.num;
            c.den = f2.den;
        }
        c.num = f1.num + numB;

        simplificar(c);

        return c;
    }

    @Override
    public boolean equals(Object obj) {
        simplificar(this);
        if (this == null || obj == null) {
            return false;
        }
        if (this == obj) {
            return true;
        }
        Fracao fc = null;
        boolean isInterger = false;
        if (this.getClass() != obj.getClass()) {
            if (!(isInterger = obj.getClass().toString().equals("class java.lang.Integer"))) {

                return false;
            } else {
                fc = new Fracao((int) obj);
            }
        }
        if (!isInterger)
            fc = (Fracao) obj;
        if (this.den == fc.den && this.num == fc.num) {

            return true;
        }

        return false;


    }

    @Override
    public String toString() {
        simplificar(this);
        if (num % den == 0) {
            valor = num / den;
            return "" + valor + "  ";
        }
        return num + "/" + den;
    }

    public String getFracaoMode() {
        return num + "/" + den;
    }

    @Override
    public int hashCode() {
        simplificar(this);
        return this.num / this.den;
    }

    public void atribuir(int valor) {
        this.valor = valor;
        this.num = valor;
        this.den = 1;
    }

    public void atribuir(int num, int den) {
        this.num = num;
        if (den < 0) {
            this.num *= -1;
            den *= -1;
        }
        this.den = den;
        simplificar(this);
    }
}