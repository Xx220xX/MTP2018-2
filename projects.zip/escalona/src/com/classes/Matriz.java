package com.classes;


import java.util.InputMismatchException;
import java.util.Scanner;
class NotInverseMatrizException extends Throwable {
    public NotInverseMatrizException() {
        super("Nao é uma matriz inversa");
    }
}

class ImpossibleMultipliqueMatrizExcepction extends Throwable {
    public ImpossibleMultipliqueMatrizExcepction() {
        super("Nao foi possivel Fazer a multiplicacao das matrizes ");
    }
}

public class Matriz {
    /**
     * Escrito por Henrique
     * o codigo a seguir faz varias operacoes para obter uma matriz reduzida por linhas
     * tmb acha a inversa,sera adiacionado uma funcao q faça isso de maneira mais pratica
     */
    public static final int INVERSA = 1;
    public static final int PADRAO = 2;
    private Fracao matriz[][] = null;
    private int index = 0, index2 = 0, ignorar = 0;
    private String matrizInicial;

    //*****************************CONSTRUTORES*******************************************
    public Matriz() {
        this.matriz = preencherMatriz(this.matriz);
        this.matrizInicial = this.toString();
    }

    public Matriz(Fracao[][] fracoes, int ordem) {
        this.matriz = Matriz.copyFracao(fracoes);
        this.index = ordem;
        this.index2 = 2 * ordem;
        this.ignorar = ordem;
        this.matrizInicial = this.toString();
    }

    public Matriz(Fracao[][] fc) {

        this.matriz = Matriz.copyFracao(fc);
        if (this.matriz == null) throw new Error();
        this.index = fc.length;
        this.index2 = fc[0].length;
        this.ignorar = fc[0].length;
        this.matrizInicial = this.toString();
    }


    public Matriz(int Type) {
        if (Type == INVERSA) {
            this.matriz = preencherMatrizInversa(this.matriz);
            this.matrizInicial = this.toString();

        } else if (Type == PADRAO) {
            this.index2 = 4;
            this.index = 2;
            this.ignorar = 2;
            this.matriz = new Fracao[index][index2];
            for (int i = 0; i < index; i++)
                for (int j = 0; j < index2; j++)
                    this.matriz[i][j] = new Fracao(1);
            this.matrizInicial = this.toString();

        } else {
            this.matriz = preencherMatriz(this.matriz);
            this.matrizInicial = this.toString();
        }
    }
    //^^^^^^^^^^^^^^^^^^^^********CONSTRUTORES********^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^


    public static String getStringByFracao(Fracao[][] mt, int ignore) {
        //PARA RETORNAR UMA STRING PARA PRINTAR ARRAYS DE FRACOES
        boolean ignorarIgnore = !(ignore == mt[0].length);
        StringBuilder str = new StringBuilder();
        for (Fracao[] aMatriz : mt) {
            for (int j = 0; j < mt[0].length; j++) {
                if (ignorarIgnore && j == ignore)
                    str.append("|\t");

                str.append(aMatriz[j] + "\t");
            }
            str.append("\n");
        }
        str.append("\n");
        return str.toString();
    }

    public static void subtrair(Fracao matriz[][], int k, int j) {

        for (int i = k + 1; i < matriz.length; i++) {
            if (!matriz[i][j].equals(0)) {
                subtrairLinha(matriz[i], matriz[k]);
                System.out.println("linha " + (i + 1) + " - " + "linha " + (k + 1));
            }
        }
    }


    private static void subtrairLinha(Fracao linhaA[], Fracao linhaB[]) {
        // linha A menos linha B
        for (int i = 0; i < linhaA.length; i++) {
            Fracao.subtrairFracao(linhaA[i], linhaB[i]);
        }
    }

    public static void subLinha(Fracao matriz[][], int linhaA, int linhaB) {
        // trocar linhas
        Fracao[] aux = matriz[linhaA];
        matriz[linhaA] = matriz[linhaB];
        matriz[linhaB] = aux;

    }

    public static void dividirLinha(Fracao matriz[][], int i, Fracao Fracao) {
        Fracao escalar = new Fracao(Fracao);
        if (escalar.equals(1)) return;

        System.out.println("linha " + (i + 1) + " dividido por " + escalar);
        for (int j = 0; j < matriz[i].length; j++) {
            Fracao.dividir(matriz[i][j], escalar);
        }
    }

    public static boolean linhaNula(Fracao f[][], int i, int ignore) {
//        System.out.println("linha nula");
        // se a linha for nula retorna true
        for (int j = 0; j < ignore; j++) {
            if (!f[i][j].equals(0)) return false;
        }
        return true;
    }

    public static Matriz multiplicar(Matriz a, Matriz b) throws ImpossibleMultipliqueMatrizExcepction {
        if (a.matriz[0].length != b.matriz.length) {
            throw new ImpossibleMultipliqueMatrizExcepction();
        }
        Fracao fc[][] = new Fracao[a.matriz.length][b.matriz[0].length];
        for (int i = 0; i < a.matriz.length; i++) {
            for (int j = 0; j < b.matriz[0].length; j++) {
                fc[i][j] = new Fracao(0);
                for (int k = 0; k < b.matriz.length; k++) {
                    fc[i][j] = new Fracao(Fracao.somarFracao(fc[i][j], Fracao.multiplicar(a.matriz[i][k], b.matriz[k][j], true), true));
                }

            }
        }
        return new Matriz(fc);
    }

    public static Fracao[][] copyFracao(Fracao[][] f) {
        int indexI = f.length, indexJ = f[0].length;
        Fracao fc[][] = new Fracao[indexI][indexJ];
        for (int i = 0; i < indexI; i++) {
            for (int j = 0; j < indexJ; j++) {
                fc[i][j] = new Fracao(f[i][j]);
            }
        }
        return fc;
    }

    public static Matriz acrescentarIdentidade(Fracao[][] fc) {
        //metodo para  criar uma matriz almentada do tipo M = I
        if (fc.length != fc[0].length) {
            System.out.println("impossivel achar inversa de matriz nao quadrada");
            return new Matriz(fc);
        }
        Fracao[][] completa = new Fracao[fc.length][(2 * fc.length)];
        for (int i = 0; i < completa.length; i++) {
            for (int j = 0; j < completa[i].length; j++) {
                if (j < fc.length) {
                    completa[i][j] = fc[i][j];
                    continue;
                }
                if (j == fc.length + i) {
                    completa[i][j] = new Fracao(1);
                    continue;
                }
                completa[i][j] = new Fracao(0);
            }
        }
        Matriz mat = new Matriz(completa, completa.length);
        mat.escalonar();
        return mat;
    }

    public static Matriz getInversa(Matriz mt) throws NotInverseMatrizException {
        if (mt.index != mt.index2 / 2) {
            throw new NotInverseMatrizException();
        } else if (mt.matriz == null) {
            throw new NullPointerException("matriz Nula ");
        }

        Fracao[][] inversa = new Fracao[mt.index][mt.index];
        for (int i = 0; i < mt.index; i++) {
            for (int j = 0; j < mt.index; j++) {
                inversa[i][j] = new Fracao(mt.matriz[i][j + mt.index]);
            }
        }
        return new Matriz(inversa);
    }

    public String getMatrizInicial() {
        return matrizInicial;
    }

    @Override
    public String toString() {
        boolean ignorarIgnore = !(this.ignorar == matriz[0].length);
        StringBuilder str = new StringBuilder();
        for (Fracao[] aMatriz : matriz) {
            for (int j = 0; j < matriz[0].length; j++) {
                if (ignorarIgnore && j == this.ignorar)
                    str.append("|\t");

                str.append(aMatriz[j] + "\t");
            }
            str.append("\n");
        }
        str.append("\n");
        return str.toString();
    }


    public Matriz clone() {
        Matriz m = new Matriz(PADRAO);
        m.matriz = copyFracao(this.matriz);
        m.index2 = this.index2;
        m.index = this.index;
        return m;

    }


    private Fracao[][] preencherMatriz(Fracao[][] fracaos) {
        System.out.println("tamanho da matriz almentanda");
        Scanner sc = new Scanner(System.in);
        do {
            try {
                System.out.print("linhas : ");
                index = sc.nextInt();
                if (index <= 0) throw new InputMismatchException();
            } catch (InputMismatchException e) {
                System.out.println("APenas numeros ");
                sc.nextLine();
            }
        } while (index <= 0);

        do {
            try {
                System.out.print("colunas : ");
                index2 = sc.nextInt();
                if (index2 <= 0) throw new InputMismatchException();
            } catch (InputMismatchException e) {
                System.err.println("APenas numeros ");
                System.out.print("colunas : ");
                sc.nextLine();
            }
        } while (index2 <= 0);
        int aux = 0;
        do {
            try {
                System.out.print("colunas da matriz normal : ");
                aux = sc.nextInt();
                if (aux <= 0) throw new InputMismatchException();
            } catch (InputMismatchException e) {
                System.err.println("APenas numeros ");
                System.out.print("colunas da matriz normal  : ");
                sc.nextLine();
            }
        } while (aux <= 0);
        fracaos = new Fracao[index][index2];
        for (int i = 0; i < fracaos.length; i++)
            for (int j = 0; j < fracaos[i].length; j++) {
                System.out.print("preencha a posicao " + (i + 1) + " " + (j + 1) + "  ");
                String fracao = sc.next();
                fracaos[i][j] = Fracao.StringToFracao(fracao);
            }

        sc.close();
        ignorar = aux == fracaos[0].length ? fracaos[0].length : (index2 - aux);
        return fracaos;
    }

    private Fracao[][] preencherMatrizInversa(Fracao[][] fracaos) {

        Scanner sc = new Scanner(System.in);
        int ordem = 0;
        do {
            try {
                System.out.println("Ordem da matriz");
                ordem = sc.nextInt();
                if (ordem <= 1) throw new InputMismatchException();
            } catch (InputMismatchException e) {
                System.out.println("APenas numeros ");
                sc.nextLine();
            }
        } while (ordem <= 1);
        index = ordem;
        index2 = 2 * ordem;

        fracaos = new Fracao[index][index2];

        for (int i = 0; i < fracaos.length; i++)
            for (int j = 0; j < fracaos[i].length; j++) {
                if (j >= ordem) {
                    if (j == i + ordem) {
                        fracaos[i][j] = new Fracao(1);
                    } else {
                        fracaos[i][j] = new Fracao(0);
                    }

                    continue;
                }
                System.out.print("preencha a posicao " + (i + 1) + " " + (j + 1) + "  ");
                String fracao = sc.next();
                fracaos[i][j] = Fracao.StringToFracao(fracao);
            }

        sc.close();
        ignorar = ordem;
        return fracaos;
    }

    //*****************************ESCALONAR*******************************************
    public void escalonar() {
        escalonar(this.matriz, this.ignorar);
    }

    private void escalonar(Fracao matriz[][], int ignore) {

        ordena(matriz, ignore);
        int i = 0, j = 0;
        while (i < matriz.length && j < matriz[i].length) {
            if (matriz[i][j].equals(0)) {
                j++;
                continue;
            }
            tornar1(matriz, i, j);
            subtrair(matriz, i, j);
            System.out.println(this);


            i++;
            j++;
        }
        ordena(matriz, ignore);
        reduzidaPorLinha(matriz, ignore);
    }

    private void reduzidaPorLinha(Fracao[][] mat, int ignore) {

        int i = 0, j = 0;//index da matriz
        while (j < ignore) {//representa onde esta o '=' na equacao A*X=B
            if (coluna0(mat, i, j) == -1) j++; //caso nesta coluna tds sejam nulos pula para proxima
            tornar1(mat, i, j);//torna 1 o elemento Aij dividindo td linha pelo msm
            i++;
        }
        for (i = 0; i < mat.length; i++) {
            if (linhaNula(mat, i)) continue;//nao usar linhas nulas
            j = pivo(mat[i]);
            if (!isPivo(mat, i, j)) continue;//se nao for um pivo continua
            for (int k = 0; k < mat.length; k++) {
                if (k == i) continue;
                if (mat[k][j].equals(0)) continue;
                System.out.println("linha " + (k + 1) + " menos " + mat[k][j] + " linha " + (i + 1));
                subtrairPorEscalar(mat[k], j, mat[i]);
                System.out.println(Matriz.getStringByFracao(mat, ignore));

            }
        }
    }

    private int pivo(Fracao[] fracoes) {
        for (int i = 0; i < fracoes.length; i++) {
            if (!fracoes[i].equals(0)) return i;
        }
        throw new Error("linha nula nao capturada");
    }

    private boolean isPivo(Fracao[][] mat, int i, int j) {
        if (mat[i][j].equals(0)) return false;//se o termo for zero , ja nao é um pivo
        for (int k = j - 1; k >= 0; k--)
            if (!mat[i][k].equals(0)) return false;// se a esquerda conter algo diferente de 0, ele nao é um  pivo
        if (!mat[i][j].equals(1))//caso seja um pivo diferente de 1
            dividirLinha(mat, i, mat[i][j]);
        return true;// é um pivo

    }

    private void subtrairPorEscalar(Fracao[] mat, int termo, Fracao[] mat2) {
//     linha mat - mat[j]* mat2, mat2 é  a linha q contem o vetor diretor, mat[termo] é o termo q sera multiplicado  pela linha do vetor diretor
        Fracao aux = new Fracao(mat[termo]);
        for (int i = 0; i < mat2.length; i++) {
            Fracao b = new Fracao(Fracao.multiplicar(aux, mat2[i], true));
//            System.out.println(b);
            Fracao.subtrairFracao(mat[i], b);

        }
    }

    private void ordena(Fracao matriz[][], int ignore) {
        int iFim = matriz.length;//numero de linhas
        for (int l = 0; l < ignore / 2; l++) {
            for (int i = 0; i < iFim; i++) {
                if (l == i) continue;
                for (int i2 = 0; i2 < iFim; i2++) {
                    if (i == i2) continue;
                    if (Fracao.comparaMaior(matriz[i][l], matriz[i2][l], true)) {
                        System.out.println("Trocar linha " + (i + 1) + " com " + (i2 + 1));
                        subLinha(matriz, i, i2);
                        System.out.println(this);
                        continue;
                    }
                }
            }
        }
    }

    private void tornar1(Fracao mt[][], int i, int j) {
        int iFim = mt.length;
        while (i < iFim) {
            if (!mt[i][j].equals(0) && !mt[i][j].equals(1)) {
                // se retornar falso o numero nao é zero assim nao divide por 0e nem por 1
                dividirLinha(mt, i, mt[i][j]);

                System.out.println(getStringByFracao(mt, this.ignorar));
            }
            i++;
        }
    }

    private int coluna0(Fracao matriz[][], int k, int j) {
//    retorna uma posicao linha em q a fracao seja diferente de 0
        for (int i = k; i < matriz.length; i++)
            if (!matriz[i][j].equals(0)) return j;
        return -1;

    }

    public boolean linhaNula(Fracao f[][], int i) {
        return linhaNula(f, i, f.length);
    }
    //^^^^^^^^^^^^^^^^^^^^********ESCALONAR********^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^



    public Fracao[][] getMatriz() {
        return Matriz.copyFracao(this.matriz);
    }
}