package com.classes;

public class Therad {

  public static void main(String[] args) {
       new Thread();
  }
}
