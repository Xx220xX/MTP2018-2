package com.classes;


public class Run {


    public static void main(String[] args) throws NotInverseMatrizException, ImpossibleMultipliqueMatrizExcepction {
        Fracao[][] fc = new Fracao[2][2];
       /* for (int i = 0; i < fc.length; i++) {
            for (int j = 0; j < fc[i].length; j++) {
                Random rd = new Random();
                fc[i][j] = new Fracao(rd.nextInt(10));
            }
        }*/
        fc[0][0] = new Fracao(2);
        fc[0][1] = new Fracao(3);
        fc[1][0] = new Fracao(5);
        fc[1][1] = new Fracao(8);
        Matriz A = new Matriz(fc);
        Matriz.acrescentarIdentidade(A.getMatriz());
        Matriz inversa = Matriz.getInversa(Matriz.acrescentarIdentidade(A.getMatriz()));
        Matriz multiplicada = Matriz.multiplicar(A, inversa);
//
        System.out.println("\nantes de escalonar \n" + A + "Inversa\n");
        System.out.println(inversa);
        System.out.println("inicial vezes Inversa");
        System.out.println(multiplicada);
        System.out.println("fim");
    }
}
