package main.java.classes;
//package classes;
import java.util.InputMismatchException;
import java.util.Scanner;

public class Humano extends Jogador {

    Scanner inserir = new Scanner(System.in);
    private int num;
    public char xar;

    public Humano(int player, Tabela table) {
        this.tabela = table;
        System.out.println("Insira seu nome");
        this.nome = inserir.next();
        tabela.player = player;
        System.out.println("  ola, " + this.nome);
        System.out.println("Player " + player + " adicionado");
        System.out.println("*****************");
    }

    public int criarXar() {
        if (tabela.escXar == 0) {
            int escolher;
            do {
                try {
                    System.out.println("1  para "+VarXar.variavelX+"\n2 para "+VarXar.variavelO);
                    escolher = inserir.nextInt();
                    tabela.escXar = escolher;
                    if (escolher != 1 && escolher != 2) {
                        throw new InputMismatchException();
                    }
                    break;
                } catch (InputMismatchException e) {
                    System.err.println("caractere invalido");
                    inserir.nextLine();
                    continue;
                }
            } while (true);
            return escolher;
        }
        if (tabela.escXar == 1) {
            this.xar = VarXar.variavelX;
        } else if (tabela.escXar == 2) {
            this.xar = VarXar.variavelO;
        } else {
            System.err.println("ERRO 12");
            throw new Error();
        }

        //atribuir valor nn escolhido
        return 3;
    }

    @Override
    public void jogar() {
        tabela.mostrar();

        System.out.println(xar + " na posição");
        do {
            try {
                num = inserir.nextInt();
                if (tabela.b1 && num == 1) {
                    tabela.l1 = xar;
                    tabela.b1 = false;
                } else if (tabela.b2 && num == 2) {
                    tabela.l2 = xar;
                    tabela.b2 = false;
                } else if (tabela.b3 && num == 3) {
                    tabela.l3 = xar;
                    tabela.b3 = false;
                } else if (tabela.b4 && num == 4) {
                    tabela.l4 = xar;
                    tabela.b4 = false;
                } else if (tabela.b5 && num == 5) {
                    tabela.l5 = xar;
                    tabela.b5 = false;
                } else if (tabela.b6 && num == 6) {
                    tabela.l6 = xar;
                    tabela.b6 = false;
                } else if (tabela.b7 && num == 7) {
                    tabela.l7 = xar;
                    tabela.b7 = false;
                } else if (tabela.b8 && num == 8) {
                    tabela.l8 = xar;
                    tabela.b8 = false;
                } else if (tabela.b9 && num == 9) {
                    tabela.l9 = xar;
                    tabela.b9 = false;
                } else {
                    System.err.println("posicnao invalida");
                    throw new InputMismatchException();
                }
                break;
            } catch (InputMismatchException e) {
                System.err.println("caractere invalido");
                System.out.println(xar + "no numero:");
                inserir.nextLine();
                continue;
            }
        } while (true);
    }
}
