package main.java.classes;
//package classes;
public final class VarXar {
    public static final char variavelX = 'X';
    public static final char variavelO = 'O';
    public static final char variavelDaVelha='⬛';
    

}
