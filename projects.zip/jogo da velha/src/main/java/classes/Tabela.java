package main.java.classes;
//package classes;
import java.util.Random;

public class Tabela {

    protected int vitoria = 0;
    public int rodada;
    public int player = 0;
    public int escXar = 0;
    public int mode = 0;
    private Random ran = new Random();
    //variaveis da tabelay
    public char l1 = 49;
    public char l2 = 50;
    public char l3 = 51;
    public char l4 = 52;
    public char l5 = 53;
    public char l6 = 54;
    public char l7 = 55;
    public char l8 = 56;
    public char l9 = 57;
    // variaveis ante repeticao;
    protected boolean b1 = true;
    protected boolean b2 = true;
    protected boolean b3 = true;
    protected boolean b4 = true;
    protected boolean b5 = true;
    protected boolean b6 = true;
    protected boolean b7 = true;
    protected boolean b8 = true;
    protected boolean b9 = true;

    public void mostrar() {
        System.out.println("   " + l1 + "|" + l2 + "|" + l3 + "\n   " + l4 + "|" + l5 + "|" + l6 + "\n   " + l7
                + "|" + l8 + "|" + l9);
    }

    public void teste() {
        //linhas
        if (l1 == l2 && l2 == l3) {
            vitoria = 1;
        }
        if (l4 == l5 && l5 == l6) {
            vitoria = 1;
        }
        if (l7 == l8 && l8 == l9) {
            vitoria = 1;
        }
        //colunas
        if (l1 == l4 && l4 == l7) {
            vitoria = 1;
        }
        if (l2 == l5 && l5 == l8) {
            vitoria = 1;
        }
        if (l3 == l6 && l6 == l9) {
            vitoria = 1;
        }
        // transversais
        if (l1 == l5 && l5 == l9) {
            vitoria = 1;
        }
        if (l3 == l5 && l5 == l7) {
            vitoria = 1;
        }

    }

    public int help() {
        int[] posicaoN = new int[9];
        int index = 0;
        if (b1) {
            posicaoN[index] = 1;
            index++;
        }

        if (b2) {
            posicaoN[index] = 2;
            index++;
        }

        if (b3) {
            posicaoN[index] = 3;
            index++;
        }

        if (b4) {
            posicaoN[index] = 4;
            index++;
        }

        if (b5) {
            posicaoN[index] = 5;
            index++;
        }

        if (b6) {
            posicaoN[index] = 6;
            index++;
        }

        if (b7) {
            posicaoN[index] = 7;
            index++;
        }

        if (b8) {
            posicaoN[index] = 8;
            index++;
        }

        if (b9) {
            posicaoN[index] = 9;

        }
        if (index == 1) {
            return posicaoN[index - 1];
            //caso so exista uma possibilidade nn precisa passar pelo randow
        }
        return posicaoN[ran.nextInt(index + 1)];
    }
}
