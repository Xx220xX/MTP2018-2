package main.java.classes;
//package classes;
import java.util.InputMismatchException;
import java.util.Scanner;

public class Jogo {
    public int d;
    public String dados;
    protected Tabela tabela;
    protected Jogador gamer;
    protected Jogador gamer1;
    private int pcOUHum;
    protected boolean continuar = true;
    private int rodada = 1;
    private Scanner sc = new Scanner(System.in);
    private int players = 0;
    private char v = VarXar.variavelDaVelha;

    public Jogo() {
        this.tabela = new Tabela();

        inicio();
        System.out.println("    (1) 1 player\n    (2) Multiplayer\n    (3) Maquina vs Maquina ");
        do {
            try {
                players = sc.nextInt();
                //tabela.player=players;
                if (players != 1 && players != 2 && players != 3) {
                    throw new InputMismatchException();
                } else
                    tabela.mode = players;
                break;
            } catch (InputMismatchException e) {
                System.err.println("Ops caractere invalido");
                sc.nextLine();
                continue;
            }
        } while (true);
        humOuPc();
    }

    public void humOuPc() {

        if (players == 1) {
            Humano player1 = new Humano(1, tabela);

            tabela.escXar = player1.criarXar();
            if (tabela.escXar == 1) {
                player1.xar = VarXar.variavelX;
            } else {
                player1.xar = VarXar.variavelO;
            }
            gamer1 = player1;
            Computador pc = new Computador(tabela);
            pc.nome = "computador";
            gamer = pc;
            part1();
        } else if (players == 2) {
            Humano player1 = new Humano(1, tabela);
            gamer1 = player1;
            if (player1.criarXar() == 1) {
                player1.xar = VarXar.variavelX;
                tabela.escXar = 1;
            } else {
                player1.xar = VarXar.variavelO;
                tabela.escXar = 2;
            }
            Humano play2 = new Humano(2, tabela);

            if (tabela.escXar == 1) {
                play2.xar = VarXar.variavelO;
            } else {
                play2.xar = VarXar.variavelX;
            }
            gamer = play2;
            part1();
        } else if (players == 3) {
            Computador pc2 = new Computador(tabela);
            pc2.nome = "Computador1";
            gamer1 = pc2;

            Computador pc = new Computador(tabela);
            pc.nome = "computador2";
            gamer = pc;
            part1();
        } else {
            System.err.println("erro 11");
            throw new Error("Variavel players com bug");
        }
    }

    public void part1() {

        do {
            tabela.rodada = rodada;
            System.out.println("______________________");
            System.out.println("   RODADA " + tabela.rodada);
            if (tabela.rodada % 2 != 0) {

                System.out.println(" Vez de " + gamer1.nome);
                gamer1.jogar();

            } else {
                System.out.println(" Vez de " + gamer.nome);
                gamer.jogar();

            }


            tabela.teste();
            if (tabela.vitoria == 1) {
                if (rodada % 2 != 0) {
                    dados = gamer1.nome + " ganhou a partida";
                    System.out.println(dados);
                    dados = dados + " de " + gamer.nome;
                    d = 1;

                } else {
                    dados = gamer.nome + " ganhou a partida";
                    System.out.println(dados);
                    dados = dados + " de " + gamer1.nome;
                    d = 1;

                }

                tabela.mostrar();
                continuar = false;
                break;
            }
            if (rodada == 9) {
                tabela.mostrar();
                velha();
                System.out.println("Ninguem ganhoun a partida");
                continuar = false;
                dados = "";
                d = 2;
            }
            rodada++;
        } while (continuar);

    }

    public void inicio() {
        System.out.println("              JOGO \n                 da");
        velha();
    }

    public void velha() {
        String inter = "__________________________________________________\n"
                + "" + v + "      " + v + " " + v + "" + v + "" + v + "" + v + "  " + v + "       " + v + "    " + v + "  " + v + "" + v + "" + v + "" + v + "\n"
                + " " + v + "    " + v + "  " + v + "        " + v + "       " + v + "    " + v + "  " + v + "   " + v + "\n"
                + "  " + v + "  " + v + "   " + v + "" + v + "" + v + "    " + v + "       " + v + "" + v + "" + v + "" + v + "  " + v + "" + v + "" + v + "" + v + "\n"
                + "   " + v + "" + v + "    " + v + "        " + v + "       " + v + "    " + v + "  " + v + "   " + v + "\n"
                + "    " + v + "     " + v + "" + v + "" + v + "" + v + "  " + v + "" + v + "" + v + "   " + v + "    " + v + "  " + v + "   " + v + "\n"
                + "________________________________________________";

     animacao(inter);
    }
    protected void animacao(String inter) {
        long inicio = System.currentTimeMillis();
        long tempo;

        int index = 0;
        long aux = 0;
        long condicao = 0;
        for (int i = 0; index < inter.length(); i++) {
            tempo = System.currentTimeMillis();
            condicao = tempo - inicio;

            if (condicao % 10 == 0) {
                if (aux != tempo) {
                    System.out.print(inter.charAt(index));
                    index++;
                    aux = tempo;
                }
            }
        }
        System.out.println();
    }

}
