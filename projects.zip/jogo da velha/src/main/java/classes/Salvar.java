//package main.java.classes;
package classes;
import java.io.IOException;
import java.io.*;

public class Salvar {
    public void arquivo(String dados, int d) {
        String lugar1 = "/sdcard/JavaNIDE/Testes/Velha/src/main/java/logs/historico.text";
        String lugar2 = "Velhagame/src/main/java/logs/historico.text";
        String local = "";
        String s;

        String c = "";
        //lendo

        if (d == 1 || true) {
            try {
                FileReader fr = new FileReader(lugar1);
                BufferedReader br = new BufferedReader(fr);
                System.err.println("arquivo lido");
                local = lugar1;
                //equanto tiver dados na linha imprima
                while ((s = br.readLine()) != null) {
                    if (d == 1) {
                        c = c + s + "\n";
                    }
                }
            } catch (IOException e) {
                try {
                    FileReader fr = new FileReader(lugar2);
                    local = lugar2;
                    BufferedReader br = new BufferedReader(fr);
                    while ((s = br.readLine()) != null) {
                        if (d == 1) {
                            c = c + s + "\n";
                        }
                    }
                } catch (IOException ex) {

                }
            }
            try

            {
                FileWriter fw = new FileWriter(local);
                BufferedWriter bw = new BufferedWriter(fw);
                if (d == 1) {
                    bw.write(c);
                }
                bw.newLine();
                bw.write(dados);
                bw.flush();
                bw.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
