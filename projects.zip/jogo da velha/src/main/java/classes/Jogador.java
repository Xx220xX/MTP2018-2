
//package classes;
//import classes.Tabela;
//import classes.VarXar;
package main.java.classes;
import main.java.classes.Tabela;
import main.java.classes.VarXar;

public abstract class Jogador {

    public String nome;
    protected Tabela tabela;

    public abstract void jogar();

    protected void animacao() {
        long inicio = System.currentTimeMillis();
        long tempo;
        int loop = 0;
        long aux = 0;
        long condicao = 0;
        for (int i = 0; loop < 5; i++) {
            tempo = System.currentTimeMillis();
            condicao = tempo - inicio;

            if (condicao % 500 == 0) {
                if (aux != tempo) {
                    System.out.print("⬛");
                    loop++;
                    aux = tempo;
                }
            }
        }
    }

}
