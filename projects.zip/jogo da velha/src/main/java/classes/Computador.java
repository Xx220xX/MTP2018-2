package main.java.classes;
//package classes;

import java.util.Random;

public class Computador extends Jogador {
    private int player;
    private int posicao;
    private Random ran = new Random();
    private char xar;

    public Computador(Tabela table) {
        this.tabela = table;
        ++this.tabela.player;
        if (this.tabela.mode == 3) {
            ++this.tabela.escXar;
        }

        this.player = this.tabela.player;
        if (this.tabela.escXar == 1) {
            this.xar = VarXar.variavelO;
        } else {
            if (this.tabela.escXar != 2) {
                System.err.println("ERRO 12");
                throw new Error("consulteo arquivo bugs.text");
            }

            this.xar = VarXar.variavelX;
        }

    }

    //METODO JOGAR
    public void jogar() {
        this.tabela.mostrar();
        int posicao = this.possibilidades();
        int local = this.escolherP(posicao);
        System.out.println("\n" + this.nome + " escolheu a posicao " + local);
        System.out.println(".............................................");
        this.mudarTabela(local);

    }

    // METODO Q VERIFICA AS MELHORES POSSIBILIDADES
    private int possibilidades() {
        System.out.println("PROCESSANDO ");
        animacao();
        if (this.tabela.rodada == 1) {
            return 19;
        } else {
            if (this.tabela.rodada == 2) {
                return jogada2();
            } else if (this.tabela.l1 == this.tabela.l2 && this.tabela.b3) {
                return 3;
            } else {
                return demaisjogadas();
            }
        }
    }

    private int demaisjogadas() {
        int ganho = euganho();
        if(ganho!=0){
            return ganho;
        }
        if (this.tabela.l2 == this.tabela.l3 && this.tabela.b1) {
            return 1;
        } else if (this.tabela.l4 == this.tabela.l5 && this.tabela.b6) {
            return 6;
        } else if (this.tabela.l5 == this.tabela.l6 && this.tabela.b4) {
            return 4;
        } else if (this.tabela.l7 == this.tabela.l8 && this.tabela.b9) {
            return 9;
        } else if (this.tabela.l8 == this.tabela.l9 && this.tabela.b7) {
            return 7;
        } else if (this.tabela.l1 == this.tabela.l4 && this.tabela.b7) {
            return 7;
        } else if (this.tabela.l4 == this.tabela.l7 && this.tabela.b1) {
            return 1;
        } else if (this.tabela.l2 == this.tabela.l5 && this.tabela.b8) {
            return 8;
        } else if (this.tabela.l5 == this.tabela.l8 && this.tabela.b2) {
            return 2;
        } else if (this.tabela.l3 == this.tabela.l6 && this.tabela.b9) {
            return 9;
        } else if (this.tabela.l6 == this.tabela.l9 && this.tabela.b3) {
            return 3;
        } else if (this.tabela.l1 == this.tabela.l5 && this.tabela.b9) {
            return 9;
        } else if (this.tabela.l5 == this.tabela.l9 && this.tabela.b1) {
            return 1;
        } else if (this.tabela.l3 == this.tabela.l5 && this.tabela.b7) {
            return 7;
        } else if (this.tabela.l5 == this.tabela.l7 && this.tabela.b3) {
            return 3;
        } else if (this.tabela.l1 == this.tabela.l3 && this.tabela.b2) {
            return 2;
        } else if (this.tabela.l1 == this.tabela.l9 && this.tabela.b5) {
            return 5;
        } else if (this.tabela.l1 == this.tabela.l7 && this.tabela.b4) {
            return 4;
        } else if (this.tabela.l2 == this.tabela.l8 && this.tabela.b5) {
            return 5;
        } else if (this.tabela.l3 == this.tabela.l9 && this.tabela.b6) {
            return 6;
        } else if (this.tabela.l3 == this.tabela.l7 && this.tabela.b5) {
            return 5;
        } else if (this.tabela.l4 == this.tabela.l6 && this.tabela.b5) {
            return 5;
        } else if (this.tabela.l7 == this.tabela.l9 && this.tabela.b8) {
            return 8;
        } else {
            return this.contraManha();
        }
    }

    private int euganho() {

        if ((this.tabela.l2 == xar) && this.tabela.l2 == this.tabela.l3 && (this.tabela.l3 == xar) && this.tabela.b1) {
            return 1;
        } else if ((this.tabela.l4 == xar) && this.tabela.l4 == this.tabela.l5 && (this.tabela.l5 == xar) && this.tabela.b6) {
            return 6;
        } else if ((this.tabela.l5 == xar) && this.tabela.l5 == this.tabela.l6 && (this.tabela.l6 == xar) && this.tabela.b4) {
            return 4;
        } else if ((this.tabela.l7 == xar) && this.tabela.l7 == this.tabela.l8 && (this.tabela.l8 == xar) && this.tabela.b9) {
            return 9;
        } else if ((this.tabela.l8 == xar) && this.tabela.l8 == this.tabela.l9 && (this.tabela.l9 == xar) && this.tabela.b7) {
            return 7;
        } else if ((this.tabela.l1 == xar) && this.tabela.l1 == this.tabela.l4 && (this.tabela.l4 == xar) && this.tabela.b7) {
            return 7;
        } else if ((this.tabela.l4 == xar) && this.tabela.l4 == this.tabela.l7 && (this.tabela.l7 == xar) && this.tabela.b1) {
            return 1;
        } else if ((this.tabela.l2 == xar) && this.tabela.l2 == this.tabela.l5 && (this.tabela.l5 == xar) && this.tabela.b8) {
            return 8;
        } else if ((this.tabela.l5 == xar) && this.tabela.l5 == this.tabela.l8 && (this.tabela.l8 == xar) && this.tabela.b2) {
            return 2;
        } else if ((this.tabela.l3 == xar) && this.tabela.l3 == this.tabela.l6 && (this.tabela.l6 == xar) && this.tabela.b9) {
            return 9;
        } else if ((this.tabela.l6 == xar) && this.tabela.l6 == this.tabela.l9 && (this.tabela.l9 == xar) && this.tabela.b3) {
            return 3;
        } else if ((this.tabela.l1 == xar) && this.tabela.l1 == this.tabela.l5 && (this.tabela.l5 == xar) && this.tabela.b9) {
            return 9;
        } else if ((this.tabela.l5 == xar) && this.tabela.l5 == this.tabela.l9 && (this.tabela.l9 == xar) && this.tabela.b1) {
            return 1;
        } else if ((this.tabela.l3 == xar) && this.tabela.l3 == this.tabela.l5 && (this.tabela.l5 == xar) && this.tabela.b7) {
            return 7;
        } else if ((this.tabela.l5 == xar) && this.tabela.l5 == this.tabela.l7 && (this.tabela.l7 == xar) && this.tabela.b3) {
            return 3;
        } else if ((this.tabela.l1 == xar) && this.tabela.l1 == this.tabela.l3 && (this.tabela.l3 == xar) && this.tabela.b2) {
            return 2;
        } else if ((this.tabela.l1 == xar) && this.tabela.l1 == this.tabela.l9 && (this.tabela.l9 == xar) && this.tabela.b5) {
            return 5;
        } else if ((this.tabela.l1 == xar) && this.tabela.l1 == this.tabela.l7 && (this.tabela.l7 == xar) && this.tabela.b4) {
            return 4;
        } else if ((this.tabela.l2 == xar) && this.tabela.l2 == this.tabela.l8 && (this.tabela.l8 == xar) && this.tabela.b5) {
            return 5;
        } else if ((this.tabela.l3 == xar) && this.tabela.l3 == this.tabela.l9 && (this.tabela.l9 == xar) && this.tabela.b6) {
            return 6;
        } else if ((this.tabela.l3 == xar) && this.tabela.l3 == this.tabela.l7 && (this.tabela.l7 == xar) && this.tabela.b5) {
            return 5;
        } else if ((this.tabela.l4 == xar) && this.tabela.l4 == this.tabela.l6 && (this.tabela.l6 == xar) && this.tabela.b5) {
            return 5;
        } else if ((this.tabela.l7 == xar) && this.tabela.l7 == this.tabela.l9 && (this.tabela.l9 == xar) && this.tabela.b8) {
            return 8;
        }
        return 0;
    }

    private int jogada2() {

        if (!this.tabela.b1) {
            return 10;
        }

        if (!this.tabela.b3) {
            return 11;
        }

        if (!this.tabela.b7) {
            return 12;
        }

        if (!this.tabela.b9) {
            return 13;
        }

        if (!this.tabela.b5) {
            return 14;
        }

        if (!this.tabela.b2) {
            return 15;
        }

        if (!this.tabela.b4) {
            return 16;
        }

        if (!this.tabela.b6) {
            return 17;
        }

        if (!this.tabela.b8) {
            return 18;
        }
        return 30;
    }

    // METODO CONTRAS JOGADAS EXTRATEGICAS
    private int contraManha() {
        if (this.tabela.l1 == this.tabela.l8 && this.tabela.b6) {
            return 20;
        } else if (this.tabela.l3 == this.tabela.l4 && this.tabela.b8) {

            return 21;
        } else if (this.tabela.l2 == this.tabela.l9 && this.tabela.b4) {
            return 22;
        } else if (this.tabela.l7 == this.tabela.l2 && this.tabela.b6) {
            return 23;
        } else if (this.tabela.l7 == this.tabela.l6 && this.tabela.b2) {
            return 24;
        } else if (this.tabela.l1 == this.tabela.l6 && this.tabela.b2) {
            return 25;
        } else
            return this.tabela.help();
    }

    //METODO PARA SELECIONAS UMA POSICAO DAS POSSIVEIS Q RECEBEU
    private int escolherP(int posicao) {
        System.out.println("\nescolhendo posicao");
        int[] p;
        int ind;
        if (posicao == 10) {
            p = new int[]{5, 9};
            ind = this.ran.nextInt(2);
            return p[ind];
        } else if (posicao == 11) {
            p = new int[]{5, 7};
            ind = this.ran.nextInt(2);
            return p[ind];
        } else if (posicao == 12) {
            p = new int[]{5, 3};
            ind = this.ran.nextInt(2);
            return p[ind];
        } else if (posicao == 13) {
            p = new int[]{5, 1};
            ind = this.ran.nextInt(2);
            return p[ind];
        } else if (posicao == 14) {
            p = new int[]{1, 3, 7, 9};
            ind = this.ran.nextInt(4);
            return p[ind];
        } else if (posicao == 15) {
            p = new int[]{5, 3, 1};
            ind = this.ran.nextInt(3);
            return p[ind];
        } else if (posicao == 16) {
            p = new int[]{5, 7, 1};
            ind = this.ran.nextInt(3);
            return p[ind];
        } else if (posicao == 17) {
            p = new int[]{5, 3, 9};
            ind = this.ran.nextInt(3);
            return p[ind];
        } else if (posicao == 18) {
            p = new int[]{5, 7, 9};
            ind = this.ran.nextInt(3);
            return p[ind];
        } else if (posicao == 19) {
            p = new int[]{1, 2, 3, 4, 5, 6, 7, 8, 9};
            ind = this.ran.nextInt(9);
            return p[ind];
        } else if (posicao == 20) {
            return 6;
        } else if (posicao == 21) {
            return 8;
        } else if (posicao == 22) {
            return 4;
        } else if (posicao == 23) {
            return 6;
        } else if (posicao == 24) {
            return 2;
        } else {
            return posicao;
        }
    }

    //METODO PARA MUDAR NA TABELA *ULTIMO A SER CHAMADO PELO COMPUTADOR
    private void mudarTabela(int posica) {
        this.posicao = posica;
        if (this.tabela.b1 && this.posicao == 1) {
            this.tabela.l1 = this.xar;
            this.tabela.b1 = false;
        } else if (this.tabela.b2 && this.posicao == 2) {
            this.tabela.l2 = this.xar;
            this.tabela.b2 = false;
        } else if (this.tabela.b3 && this.posicao == 3) {
            this.tabela.l3 = this.xar;
            this.tabela.b3 = false;
        } else if (this.tabela.b4 && this.posicao == 4) {
            this.tabela.l4 = this.xar;
            this.tabela.b4 = false;
        } else if (this.tabela.b5 && this.posicao == 5) {
            this.tabela.l5 = this.xar;
            this.tabela.b5 = false;
        } else if (this.tabela.b6 && this.posicao == 6) {
            this.tabela.l6 = this.xar;
            this.tabela.b6 = false;
        } else if (this.tabela.b7 && this.posicao == 7) {
            this.tabela.l7 = this.xar;
            this.tabela.b7 = false;
        } else if (this.tabela.b8 && this.posicao == 8) {
            this.tabela.l8 = this.xar;
            this.tabela.b8 = false;
        } else if (this.tabela.b9 && this.posicao == 9) {
            this.tabela.l9 = this.xar;
            this.tabela.b9 = false;
        } else {
            throw new Error("erro15");
        }
    }
}
