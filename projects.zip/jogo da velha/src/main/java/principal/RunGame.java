package main.java.principal;
//package principal;
//import classes.Jogo;
import main.java.classes.Jogo;

public class RunGame {
    public static void main(String args[]) {
  //System.registerNatives();
        long inicio= System.currentTimeMillis();
        Jogo jogo = new Jogo();
        long fim=System.currentTimeMillis();
        double tempo=((double)fim-(double)inicio)/1000;
        System.out.println("tempo de jogo "+tempo+" segundos");
/* antes defina um local para
 * armazenar um arquivo
 * na classe Salvar  
 */
        //Salvar salvar = new Salvar();
        //salvar.arquivo(jogo.dados, jogo.d);

    }
}
