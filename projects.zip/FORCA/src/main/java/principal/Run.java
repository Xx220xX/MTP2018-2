
/*
package principal;
import classes.Forca;
import classes.ImportarPalavras;
*/

package main.java.principal;

import main.java.classes.Forca;
import main.java.classes.ImportarPalavras;

public class Run {
    public static void main(String[] args) {
        ImportarPalavras ip = new ImportarPalavras();
        Forca f = new Forca(ip.toString());

    }
}
       

