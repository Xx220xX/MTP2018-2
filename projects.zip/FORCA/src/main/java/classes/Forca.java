package main.java.classes;
//package classes;


import java.text.Collator;
import java.util.InputMismatchException;
import java.util.Scanner;

public class Forca {

    private final Collator collator = Collator.getInstance();
    private String word;
    private char[] letrasJaUsadas = new char[26];
    private int i = 0;
    private Character carac = 0;
    private int contagem;
    private String cabeca = "";
    private String corpo = "";
    private String pe = "";
    private boolean dinovo = true;
    private boolean error = false;
    private String forca = "";

    public Forca(String ip) {
        collator.setStrength(Collator.NO_DECOMPOSITION);
        this.word = ip;
        start();
    }

    private void start() {
        word = word.toUpperCase();
        word = word.trim();
        int Tletra = word.length();
        boolean letraMudar[] = new boolean[Tletra];
        String[] letra = new String[Tletra];
        for (int i = 0; i < Tletra; i++) {
            letra[i] = String.valueOf(word.charAt(i));
            letraMudar[i] = true;
        }
        int erro = 0;
        // look(word, letraMudar, erro, Tletra);
        Scanner sc = new Scanner(System.in);
        String escolha = null;

        while (dinovo) {
            System.out.println(look(word, letraMudar, erro, Tletra));
            if (!dinovo) {
                break;
            }
            System.out.println("Escolha uma letras de 'A' a 'Z'");
            try {
                escolha = sc.next();
                escolha = escolha.toUpperCase();
                escolha.trim();
                if (escolha.equals("@")) {
                    System.out.println("vc desistiu");
                    morte();
                    break;
                }
                if (escolha.equals("#")) {
                    letraJausada(letrasJaUsadas);
                    break;
                }
                verificar(escolha);
                animacao(escolha);
            } catch (InputMismatchException e) {

                System.out.println("\ninsira outra letra ");
                sc.nextLine();
                continue;
            }
            boolean direto = true;
            for (int j = 0; j < Tletra; j++) {
                if (collator.compare(escolha, letra[j]) == 0) {
                    letraMudar[j] = false;
                    direto = false;
                    contagem++;
                }
            }
            if (contagem == Tletra) {
                System.out.println("###########################");
                System.out.println("PARABENS ACERTOU A PALAVRA " + word);
                dinovo = false;
            }
            if (direto == true) {
                erro++;
            }


        }

    }

    private void verificar(String escolha) throws InputMismatchException {
        carac = escolha.charAt(0);
        if (escolha.length() > 1) {
            System.err.println("insira apenas uma letra ");
            throw new InputMismatchException();
        }

        if (carac.hashCode() < 65 || carac.hashCode() > 90) {
            System.err.println("caractere ilegal");
            throw new InputMismatchException();
        }
        for (char b : letrasJaUsadas) {
            if (b == 0) {
                break;
            }
            if (b == escolha.charAt(0)) {
                letraJausada(letrasJaUsadas);

            }
        }
        letrasJaUsadas[i] = escolha.charAt(0);
        i++;
    }

    private void letraJausada(char[] letrasJaUsadas) throws InputMismatchException {
        System.out.println("\n***************************");
        System.out.println("letra ja usada \nConfira as letras ja usadas\n");
        for (char c : letrasJaUsadas) {
            System.out.print(c + "  ");
        }
        System.out.println("\n***************************\n");
        throw new InputMismatchException();
    }

    @Override
    public String toString() {
        return forca;
    }

    private String look(String word, boolean[] letraMudar, int erro, int Tletra) {

        char[] s = new char[Tletra];
        for (int i = 0; i < Tletra; i++) {
            if (letraMudar[i]) {
                s[i] = '_';
            } else {
                s[i] = word.charAt(i);
            }
        }
        String str = null;
        for (int i = 0; i < Tletra; i++) {
            if (str == null) {
                str = s[i] + "  ";
            } else {
                str = str + s[i] + "  ";
            }
        }

        personagem(erro);
        montar(error, str, Tletra, erro);
        return forca;
    }

    private void montar(boolean error, String str, int Tletra, int erro) {
        forca = "_________________________________\n" +
                "  _____          " + Tletra + " Letras      Erros " + erro + "\n" +
                "  |   " + cabeca + "\n" +
                "  |   " + corpo + "\n" +
                "  |   " + pe + "\n" +
                "  |  \n" +
                "  | " + str
                + "\n_________________________________";
        if (error) {
            forca = "errou\n" + forca;
            error = false;
        }
    }

    private void morte() {

        System.out.println("===========================");
        System.out.println("VC se enforcou :(");
        System.out.println("A palavra era \"" + word + "\"");
        dinovo = false;
    }

    private void animacao(String letra) {
        System.out.println("Letra escolhida " + letra);
        animacao();
    }

    private void animacao() {
        long inicio = System.currentTimeMillis();
        long tempo;
        int loop = 0;
        long aux = 0;
        long delta = 0;
        for (; loop < 4; ) {
            tempo = System.currentTimeMillis();
            delta = tempo - inicio;

            if (delta >= 1000 && aux != tempo) {
                loop++;
                aux = tempo;
                if (loop < 4)
                    System.out.print("⬛");

            }
        }
    }

    public void personagem(int erro) {
        if (erro == 1) {
            cabeca = " ☺";
            error = true;
        }
        if (erro == 2) {
            corpo = "/";
            error = true;
        }
        if (erro == 3) {
            cabeca = " 😢";
            corpo = "/(";
            error = true;
        }
        if (erro == 4) {
            corpo = "/()";
            error = true;
        }
        if (erro == 5) {
            corpo = "/()\\";
            error = true;
        }
        if (erro == 6) {
            cabeca = " 😟";
            pe = "_";
            error = true;
        }
        if (erro == 7) {
            pe = "_/";
            error = true;
        }
        if (erro == 8) {
            pe = "_/\\";
            error = true;
        }
        if (erro == 9) {

            cabeca = " 💀";
            pe = "_/\\_";
            error = true;
            morte();
        }
    }
}
