
package main.java.classes;
//package classes;


import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.InputMismatchException;
import java.util.Random;
import java.util.Scanner;

public class ImportarPalavras {

    private String path = System.getProperty("user.dir") + "/" + "src/files/";
    private String arquivo;
    private String word;
    private String localDefault = "/sdcard/JavaNIDE/Testes/Jogo da forca/src/files/";

    @Override
    public String toString() {
        return word;
    }

    public ImportarPalavras() {

        Scanner sc = new Scanner(System.in);
        int dificuldade = 0;
        System.out.println("Digite o nivel de DIFICULDADE DE 1 A 3 ");
        while (true) {
            try {
                dificuldade = sc.nextInt();
                if (dificuldade < 1 || dificuldade > 3) {
                    throw new InputMismatchException();
                }
                break;
            } catch (InputMismatchException e) {
                System.out.println("caractere Inválido ");
                System.out.println("INSIRA UM CARACTERE VALIDO");
                sc.nextLine();
            }
        }
        escolher(dificuldade);
    }

    public void escolher(int dificuldade) {
        if (dificuldade == 1) {
            easy();
        } else if (dificuldade == 2) {
            medium();
        } else if (dificuldade == 3) {
            hard();
        }
        try {
            words();
        } catch (IOException e) {
            words(localDefault);
        }
    }

    public void easy() {

        arquivo = path + "easy.text";
        localDefault = localDefault + "easy.text";

    }


    private void medium() {
        arquivo = path + "medium.text";
        localDefault = localDefault + "medium.text";

    }

    private void hard() {
        arquivo = path + "hard.text";
        localDefault = localDefault + "hard.text";

    }

    public void words() throws IOException {


        BufferedReader bf = new BufferedReader(new FileReader(arquivo));

        Random rd = new Random();
        int line = rd.nextInt(500);
       MyReader7 mr = new MyReader7(bf);
        word = mr.readLine(line);
        bf.close();

    }

    public void words(String local) {
        try {
            BufferedReader bf = new BufferedReader(new FileReader(local));

            Random rd = new Random();
            int line = rd.nextInt(500);

            MyReader7 mr = new MyReader7(bf);

            word = mr.readLine(line);

            bf.close();
        } catch (IOException e) {
            throw new Error();
        }
    }
}
