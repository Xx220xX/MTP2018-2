package main.java.classes;
//package classes;

import java.io.BufferedReader;
import java.io.IOException;

public class MyReader7 {
    private BufferedReader bf;
    private String[] linhas = new String[500];

    private boolean criarArray = true;

    public MyReader7(BufferedReader bf) {
        this.bf = bf;

    }

    public String readLine(int line) {
        if (criarArray) {

            int index = 0;
            try {
                while (true) {
                    String ler = bf.readLine();

                    if (ler != null && index < 500) {
                        linhas[index] = ler;

                        index++;

                        continue;
                    } else {
                        criarArray = false;
                        break;
                    }
                }
                return linhas[line];
            } catch (IOException e) {
                throw new Error();
            }
        }

        return null;
    }
}
