import java.util.Scanner;

public class P2763 {
    public static void main(String[] args) {
        String str=new Scanner(System.in).next();
        for (int i = 0; i < str.length(); i++) {
            if(str.charAt(i)=='.'||str.charAt(i)=='-'){
                System.out.println();
            }else
                System.out.print(str.charAt(i));
        }
        System.out.println();

    }
}
