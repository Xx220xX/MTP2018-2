

import java.util.Scanner;

public class P1028 {
    public static void main(String[] args) {
        int n = 0, a = 0, b = 0;
        Scanner sc = new Scanner(System.in);
        n = sc.nextInt();
        int r[] = new int[n];
        for (int i = 0; i < n; i++) {
            a = sc.nextInt();
            b = sc.nextInt();
            r[i] = mdc(a, b);
        }
        for (int c : r) {
            System.out.println(c);

        }
    }

    private static int mdc(int a, int b) {
        //3 6
        int dif = a - b;
        //-3
        int menor = b, maior = a;
        if (dif < 0) {
            menor = b - a;
            //3
            maior = a;
            //3
        } else if (dif > 0) {
            menor = a - b;
            //3
            maior = b;
            //3
        }
        if (dif == 0) {
            return maior;
        }
        if (menor != 0) {
            return mdc(maior, menor);
        }
        return maior;
    }
}
