import java.io.IOException;
import java.util.Scanner;

/**
 * IMPORTANT:
 * O nome da classe deve ser "Main" para que a sua solução execute
 * Class name must be "Main" for your solution to execute
 * El nombre de la clase debe ser "Main" para que su solución ejecutar
 */
public class Main {

    public static void main(String[] args) throws IOException {

        int n = 0, a[] , b[];
        Scanner sc = new Scanner(System.in);
        n = sc.nextInt();
        int r[] = new int[n];
        a=new int[n];
        b=new int[n];
        for (int i = 0; i < n; i++) {
            a[i] = sc.nextInt();
            b[i] = sc.nextInt();
        }
        for (int i = 0; i < n; i++) {
            r[i] = mdc(a[i], b[i]);
        }
        for (int c : r) {
            System.out.println(c);
        }

    }

    private static int mdc(int a, int b) {
        if (a == 0 || b == 0) {
            return 0;
        }

        int maior = a - b < 0 ? b : a;
        int menor = a - b < 0 ? a : b;
        int dif = maior - menor;
        while (dif != 0) {

           maior-=menor;
           if(maior<menor){
               a=maior;
               maior=menor;
               menor =a;
           }
            dif = maior - menor;
        }
        return maior;
    }

}